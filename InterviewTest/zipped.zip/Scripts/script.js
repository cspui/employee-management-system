﻿$(function () {
    console.log('Ready')

    
})